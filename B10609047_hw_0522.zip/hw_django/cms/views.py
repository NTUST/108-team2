from django.shortcuts import render_to_response,render
# Create your views here.
from .models import Restaurant, Food,Photo

def index(request):
	restaurants = Restaurant.objects.all()
	return render_to_response('cms/menu.html',locals())
def intro(request):
    return render(request,'cms/index.html')

def photo_list(request):
    queryset=Photo.objects.all()
    context={"photo":queryset}
    return render(request,"cms/index.html",context)
